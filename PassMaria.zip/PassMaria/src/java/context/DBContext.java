/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package context;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import util.AppContext;

/**
 *
 * @author XuanXuan
 */
public class DBContext {
    private String url;
    private static DBContext dbContext;
    AppContext ac = new AppContext();
    //lay bien instance dau tien cua DBContext la bien duy nhat dbContext
    public static DBContext getInstance() throws Exception{
        if(dbContext == null)
        {
            dbContext = new DBContext();
        }
        return dbContext;
    }
    //check xem url co loi ko
    public Connection getConnection() throws SQLException
    {
        Connection con = null;
        try{
            con = DriverManager.getConnection(url);
        }
        catch(Exception e)
        {
            url = ac.getDirectValue("urlConnection");
            con = DriverManager.getConnection(url);
        }
        return con;
    }
    //ko bi get instance de ton tai moi dBcontext
    private DBContext() throws Exception{
        url = ac.env("urlConnection");
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    }
}
