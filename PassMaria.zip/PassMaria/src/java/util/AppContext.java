/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.HashMap;
import java.util.Map;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author XuanXuan
 */
public class AppContext {
    private static Map<String, String> conf;
    private Context initContext;
    public AppContext(){
    conf = new HashMap();
    try{
        this.initContext = new InitialContext();
        
    }
    catch(NamingException ex)
    {
        
    }
}
    //de luu ten vao bo dem, neu ko co se lai goi ten.
    public String env(String name)
    {
        String value = conf.get(name);
        if(value == null)
        {
            value = getDirectValue(name);
            conf.put(name, value);
        }
        return value;
    }
    //goi truc tiep ten cua config
    public String getDirectValue(String name)
    {
        String value = null;
        try {
            value = (String) this.initContext.lookup("java:comp/env/" + name);
        } catch (NamingException e) {
            
        }
        return value;
    }
}
