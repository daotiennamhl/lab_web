/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ProductDAO;
import entity.product;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import util.AppContext;

/**
 *
 * @author XuanXuan
 */
public class ProductController extends HttpServlet {

    AppContext appContext = new AppContext();
    ProductDAO productDAO = new ProductDAO();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {

            int pageSize = Integer.parseInt(appContext.env("pageSize"));
            //de lay bien pageId tu trang jspp dua theo next va preview
            String pageId = request.getParameter("pageId");
            //gan gia tri ban dau la trang 1
            if (pageId == null) {
                pageId = "1";
            }
            int pageIdNumber = Integer.parseInt(pageId);
            List<product> products = productDAO.getItem(pageIdNumber, pageSize);
            //de set lai next va preview
            String next = null, preview = null;
            int count = productDAO.count();
            int totalPageSize = (int) (Math.ceil((count * 1.0) / pageSize));
            if (pageIdNumber < totalPageSize) {
                next = (pageIdNumber + 1) + "";
            }
            if (pageIdNumber > 1) {
                preview = (pageIdNumber - 1) + "";
            }
            request.setAttribute("next", next);
            request.setAttribute("preview", preview);
            request.setAttribute("products", products);
            //cai de ko fix cung lai cau hinh
            String folderimg = appContext.env("folderimage");
            String foldercss = appContext.env("foldercss");
            request.setAttribute("folderimg", folderimg);
            request.setAttribute("foldercss", foldercss);
            //de chay thang jsp ko bi thieu css
            request.setAttribute("active", "about");
            request.setAttribute("servlet", "servlet");
            request.getRequestDispatcher("/view/about.jsp").forward(request, response);
        } catch (Exception e) {
           response.sendRedirect(request.getContextPath() + "/Error");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
