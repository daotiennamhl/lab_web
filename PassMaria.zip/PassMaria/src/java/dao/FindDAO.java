/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import context.DBContext;
import entity.find;
import entity.openhour;
import entity.profile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author XuanXuan
 */
public class FindDAO extends DAO{
    public List<find> getAll() throws Exception {
        List<find> finds;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBContext.getInstance().getConnection();
            finds = new ArrayList<>();
            String query = "select * from find1";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                
                String address = rs.getString("address");
                String tel = rs.getString("tel");
                String email = rs.getString("email");
                finds.add(new find(address, tel, email));
            }
            this.close(conn, rs, ps);
        } catch (Exception e) {
            this.close(conn, rs, ps);
            throw e;
        }
        return finds;
    }
    
    
}
