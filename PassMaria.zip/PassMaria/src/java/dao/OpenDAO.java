/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import context.DBContext;
import entity.openhour;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author XuanXuan
 */
public class OpenDAO extends DAO{
    public List<openhour> get() throws Exception {
        List<openhour> opens;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBContext.getInstance().getConnection();
            opens = new ArrayList<>();
            String query = "select * from openhour";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                
                String openhour = rs.getString("openhour");
                
                opens.add(new openhour(openhour));
            }
            this.close(conn, rs, ps);
        } catch (Exception e) {
            this.close(conn, rs, ps);
            throw e;
        }
        return opens;
    }
}
