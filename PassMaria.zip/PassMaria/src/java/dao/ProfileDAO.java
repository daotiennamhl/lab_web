/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import context.DBContext;
import entity.product;
import entity.profile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author XuanXuan
 */
public class ProfileDAO extends DAO{
    public List<profile> getAll() throws Exception {
        List<profile> profiles;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBContext.getInstance().getConnection();
            profiles = new ArrayList<>();
            String query = "select * from profile";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String title = rs.getString("title");
                String description1 = rs.getString("description1");
                String description2 = rs.getString("description2");
                String img = rs.getString("img");
                profiles.add(new profile(title, description1, description2, img));
            }
            this.close(conn, rs, ps);
        } catch (Exception e) {
            this.close(conn, rs, ps);
            throw e;
        }
        return profiles;
    }

  
}
