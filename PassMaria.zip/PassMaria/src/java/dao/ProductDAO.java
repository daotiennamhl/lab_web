/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import context.DBContext;
import entity.product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author XuanXuan
 */
public class ProductDAO extends DAO{
    public List<product> getAll() throws Exception {
        List<product> products;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBContext.getInstance().getConnection();
            products = new ArrayList<>();
            String query = "select * from product";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String title = rs.getString("title");
                String shortdescription = rs.getString("shortdescription");
                String description = rs.getString("description");
                String img = rs.getString("img");
                products.add(new product(title, shortdescription, description, img, id));
            }
            this.close(conn, rs, ps);
        } catch (Exception e) {
            this.close(conn, rs, ps);
            throw e;
        }
        return products;
    }

    public List<product> getItem(int pageId, int pageSize) throws Exception {
        List<product> products;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBContext.getInstance().getConnection();
            products = new ArrayList<>();
            //ham query de sap xep so theo thu tu de vao trang ko bi lug tung
            String query = "SELECT * FROM\n"
                    + "(select *, ROW_NUMBER() OVER(ORDER BY ID) AS ROW_INDEX from product) ITEM_INCRE\n"
                    + "WhERE ITEM_INCRE.ROW_INDEX BETWEEN ? AND ?;";
            int from = (pageId - 1) * pageSize + 1;
            int to = pageId * pageSize;
            ps = conn.prepareStatement(query);
            ps.setInt(1, from);
            ps.setInt(2, to);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String title = rs.getString("title");
                String shortDescription = rs.getString("shortDescription");
                String description = rs.getString("description");
                String img = rs.getString("img");
                products.add(new product(title, shortDescription, description, img, id));
            }
            this.close(conn, rs, ps);
        } catch (Exception e) {
            this.close(conn, rs, ps);
            throw e;
        }
        return products;
    }
       public List<product> get2Item(int from, int to) throws Exception {
        List<product> products;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBContext.getInstance().getConnection();
            products = new ArrayList<>();
            //ham query de sap xep so theo thu tu de vao trang ko bi lug tung
            String query = "SELECT * FROM\n"
                    + "(select *, ROW_NUMBER() OVER(ORDER BY ID) AS ROW_INDEX from product) ITEM_INCRE\n"
                    + "WhERE ITEM_INCRE.ROW_INDEX BETWEEN ? AND ?;";
            
            ps = conn.prepareStatement(query);
            ps.setInt(1, from);
            ps.setInt(2, to);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String title = rs.getString("title");
                String shortDescription = rs.getString("shortDescription");
                String description = rs.getString("description");
                String img = rs.getString("img");
                products.add(new product(title, shortDescription, description, img, id));
            }
            this.close(conn, rs, ps);
        } catch (Exception e) {
            this.close(conn, rs, ps);
            throw e;
        }
        return products;
    }

    public int count() throws Exception {
        List<product> items;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = -1;
        try {
            conn = DBContext.getInstance().getConnection();
            String query = "select COUNT(*) AS Total from product";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt("Total");
            }
            this.close(conn, rs, ps);
        } catch (Exception e) {
            this.close(conn, rs, ps);
            throw e;
        }
        return count;
    }

    public List<product> getById(int id) throws Exception {
        List<product> products;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBContext.getInstance().getConnection();
            products = new ArrayList<>();
            String query = "select * from product Where id = ?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                int Id = rs.getInt("ID");
                String title = rs.getString("title");
                String shortDescription = rs.getString("shortDescription");
                String description = rs.getString("description");
                String img = rs.getString("img");
                products.add(new product(title, shortDescription, description, img, id));
            }
            this.close(conn, rs, ps);
        } catch (Exception e) {
            this.close(conn, rs, ps);
            throw e;
        }
        return products;
    }
}
