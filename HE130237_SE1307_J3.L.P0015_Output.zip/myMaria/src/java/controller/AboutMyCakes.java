/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.ProductDAO;
import entity.Product;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import util.AppContext;
import util.SetError;

/**
 *
 * @author namdthe130237
 */
public class AboutMyCakes extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //set default error page
        String error = "404 - Page Not Found";
        SetError se;
        String pageIndexError = null;
        try {
            //set active page
            request.setAttribute("active", "about");

            //get folder's name
            AppContext ac = new AppContext();
            String folderCss = ac.getValue("folderCss");
            String folderImg = ac.getValue("folderImg");
            request.setAttribute("folderCss", folderCss);
            request.setAttribute("folderImg", folderImg);

            //get pageSize
            String pageSize_raw = ac.getValue("pageSize");
            int pageSize = Integer.parseInt(pageSize_raw);

            //get pageIndex
            String pageIndex_raw = request.getParameter("pageIndex");
            if (pageIndex_raw == null) {
                pageIndex_raw = "1";
            }
            try {
                int pageIndex = Integer.parseInt(pageIndex_raw);
                ArrayList<Product> products = new ArrayList<>();
                ProductDAO pd = new ProductDAO();
                //get total page
                int totalProduct = pd.count();
                int totalPage = (totalProduct + pageSize - 1) / pageSize;
                //check page out of range
                if (pageIndex <= totalPage && pageIndex > 0) {
                    //paging 
                    int next = 0, preview = 0;
                    if (pageIndex > 1) {
                        preview = pageIndex - 1;
                    }
                    if (pageIndex < totalPage) {
                        next = pageIndex + 1;
                    }
                    request.setAttribute("next", next);
                    request.setAttribute("preview", preview);
                    //get products
                    products = pd.paging(pageSize, pageIndex);
                    request.setAttribute("products", products);
                } else {//page index out of range
                    pageIndexError = "Page index out of range!";
                    request.setAttribute("pageIndexError", pageIndexError);
                }
            } catch (NumberFormatException e) {//page index is not an integer
                pageIndexError = "Page index invalid!";
                request.setAttribute("pageIndexError", pageIndexError);
            }

            request.getRequestDispatcher("view/about.jsp").forward(request, response);
        } catch (Exception e) {
            se = new SetError();
            se.setError(request, response, error);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
