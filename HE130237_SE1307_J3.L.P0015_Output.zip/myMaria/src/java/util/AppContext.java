/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author namdthe130237
 */
public class AppContext {
    private Context InitContext;

    public AppContext() {
        try {
            this.InitContext = new InitialContext();
        } catch (NamingException ex) {
        }
    }
    //get value from context.xml
    public String getValue(String name){
        String value = null;
        try {
            Context con = (Context) this.InitContext.lookup("java:comp/env/");
            value = (String) con.lookup(name);
        } catch (NamingException ex) {
        }
        return value;
    }
    
}
