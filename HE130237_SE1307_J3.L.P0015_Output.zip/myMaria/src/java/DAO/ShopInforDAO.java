package DAO;

import context.DBContext;
import entity.ShopInfor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author namdthe130237
 */
public class ShopInforDAO {

    public ShopInfor getShopInfor() throws Exception {
        DBContext db = null;
        ShopInfor si = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            db = new DBContext();
            con = db.getConnection();
            String query = "select * from shopinfor";
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                String title = rs.getString("title");
                String description1 = rs.getString("description1");
                String description2 = rs.getString("description2");
                String img = rs.getString("img");
                si = new ShopInfor(title, description1, description2, img);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            db.close(ps, rs, con);
        }
        return si;
    }
}
