/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import context.DBContext;
import entity.Visit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author namdthe130237
 */
public class VisitDAO {

    public ArrayList<Visit> getVisit() throws Exception {
        DBContext db = null;
        ArrayList<Visit> visits = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            db = new DBContext();
            visits = new ArrayList<>();
            con = db.getConnection();
            String query = "select * from visit";
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                String content = rs.getString("content");
                Visit vs = new Visit(content);
                visits.add(vs);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            db.close(ps, rs, con);
        }
        return visits;
    }
}
