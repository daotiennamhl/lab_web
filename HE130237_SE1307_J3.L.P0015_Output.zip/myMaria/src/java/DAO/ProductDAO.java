/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import context.DBContext;
import entity.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author namdthe130237
 */
public class ProductDAO {
    //count number of product in database
    public int count() throws Exception {
        DBContext db = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int total = -1;
        try {
            db = new DBContext();
            con = db.getConnection();
            String query = "select count(ID) as total from product";
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                total = rs.getInt("total");
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            db.close(ps, rs, con);
        }
        return total;
    }
    //get Product int range(from, to)
    public ArrayList<Product> getProducts(int from, int to) throws Exception {
        DBContext db = null;
        ArrayList<Product> products = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            db = new DBContext();
            products = new ArrayList<>();
            con = db.getConnection();
            //select content by pageindex and pagesize
            String query = "select * from \n"
                    + "(select *, ROW_NUMBER() OVER(ORDER by id) as ROW_INDEX from product) as indexed_tbl\n"
                    + "where ROW_INDEX >= ? and ROW_INDEX <= ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, from);
            ps.setInt(2, to);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String shortDescription = rs.getString("shortdescription");
                String description = rs.getString("description");
                String img = rs.getString("img");
                String title = rs.getString("title");
                products.add(new Product(title, shortDescription, description, img, id));
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            db.close(ps, rs, con);
        }
        return products;
    }

    public ArrayList<Product> paging(int pagesize, int pageindex) throws Exception {
        return getProducts(pagesize * (pageindex - 1) + 1, pagesize * pageindex);
    }

    public Product getProductByID(int ID) throws Exception {
        DBContext db = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Product p = null;
        try {
            db = new DBContext();
            con = db.getConnection();
            String query = "select * from product where ID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, ID);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String shortDescription = rs.getString("shortdescription");
                String description = rs.getString("description");
                String img = rs.getString("img");
                String title = rs.getString("title");
                p = new Product(title, shortDescription, description, img, id);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.close(ps, rs, con);
        }
        return p;
    }

}
