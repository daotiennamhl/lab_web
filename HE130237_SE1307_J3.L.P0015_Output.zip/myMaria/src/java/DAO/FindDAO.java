/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import context.DBContext;
import entity.Find;
import entity.OpenHour;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author namdthe130237
 */
public class FindDAO {

    public Find getFind() throws Exception {
        DBContext db = null;
        Find f = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            db = new DBContext();
            con = db.getConnection();
            String query = "select * from find";
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                String address = rs.getString("address");
                String tel = rs.getString("tel");
                String email = rs.getString("email");
                f = new Find(tel, address, email);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            db.close(ps, rs, con);
        }
        return f;
    }

    public ArrayList<OpenHour> getOpenHour() throws Exception {
        DBContext db = null;
        ArrayList<OpenHour> openHours = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            db = new DBContext();
            con = db.getConnection();
            openHours = new ArrayList<>();
            String query = "select * from openhour";
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                String openHour = rs.getString("openhour");
                OpenHour op = new OpenHour(openHour);
                openHours.add(op);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            db.close(ps, rs, con);
        }
        return openHours;
    }

}
