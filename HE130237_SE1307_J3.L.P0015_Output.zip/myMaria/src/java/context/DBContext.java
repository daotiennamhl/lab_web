/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package context;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import util.AppContext;

/**
 *
 * @author namdthe130237
 */
public class DBContext {

    private String urlConnection;
    private AppContext ac = new AppContext();
    private DBContext dbContext;
    //constructor
    public DBContext() throws ClassNotFoundException{
        urlConnection = ac.getValue("urlConnection");
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    }

    //get connection
    public Connection getConnection() throws SQLException {
        Connection con;
        try {
            con = DriverManager.getConnection(urlConnection);
        } catch (Exception e) {
            urlConnection = ac.getValue("urlConnection");
            con = DriverManager.getConnection(urlConnection);
        }
        return con;
    }

    //close connection
    public void close(PreparedStatement ps, ResultSet rs, Connection con) throws SQLException {
        if (rs != null && !rs.isClosed()) {
            rs.close();
        }
        if (ps != null && !ps.isClosed()) {
            ps.close();
        }
        if (con != null && !con.isClosed()) {
            con.close();
        }
    }
}
